To install the USB driver on your computer.
1. Right-click android_winusb.inf
2. Select Install
3. Until a confirmation dialog appear.

Note: Make sure VIVE Streaming Hub and VIVE Business Console aren't running when you install the USB driver.